package org.example;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Bolo bolo1 = new Bolo();
        bolo1.sabor= "Chocolate";
        bolo1.valor= 37.5;
        Integer quantidadeBolo1 = 0;

        Bolo bolo2 = new Bolo();
        bolo2.sabor= "Morango";
        bolo2.valor= 45.0;
        Integer quantidadeBolo2 = 0;

        Bolo bolo3 = new Bolo();
        bolo3.sabor= "Abacaxi";
        bolo3.valor= 48.0;
        Integer quantidadeBolo3 = 0;

        Integer quantidadeTotalDeBolo;
        Integer opcao = null;
        Scanner leitor = new Scanner(System.in);
        do {
            System.out.println("""
                    Escolha uma opção:
                    1) Comprar bolo
                    2) Exibir relatório
                    0) Sair
                    """);
            opcao = leitor.nextInt();
            if (opcao == 1){
                System.out.println("""
                        Escolha um sabor de bolo:
                        1) Chocolate
                        2) Morango
                        3) Abacaxi
                        """);
                Integer opcaoSabor = leitor.nextInt();
                if (opcaoSabor == 1){
                    quantidadeBolo1 += 5;
                    bolo1.comprarBolo(quantidadeBolo1);
                    System.out.println("""
                            %d Bolo(s) de %s: R$%.2f
                            """.formatted(quantidadeBolo1, bolo1.sabor, bolo1.valor * quantidadeBolo1));
                }else if (opcaoSabor == 2){
                    quantidadeBolo2 += 7;
                    bolo2.comprarBolo(quantidadeBolo2);
                    System.out.println("""
                            %d Bolo(s) de %s: R$%.2f
                            """.formatted(quantidadeBolo2, bolo2.sabor, bolo2.valor * quantidadeBolo2));
                }else {
                    quantidadeBolo3 += 10;
                    bolo3.comprarBolo(quantidadeBolo3);
                    System.out.println("""
                            %d Bolo(s) de %s: R$%.2f
                            """.formatted(quantidadeBolo3, bolo3.sabor, bolo3.valor * quantidadeBolo3));
                }
                quantidadeTotalDeBolo = quantidadeBolo1 + quantidadeBolo2 + quantidadeBolo3;
            } else if (opcao == 2) {
                bolo1.exibirRelatorio();
                bolo2.exibirRelatorio();
                bolo3.exibirRelatorio();
            }
        }while (opcao != 0);
    }
}